BABY TOMATO'S DIARY

The website entry file is index.html and is already at the root of this folder.

To use it on your device:
- Open index.html in a modern browser.
- Your writing is saved in that browser's local storage. Export backups regularly.

To publish with GitHub Pages:
1. Create or open a GitHub repository.
2. Upload index.html to the repository's top level (not inside another folder).
3. In the repository, open Settings -> Pages.
4. Choose Deploy from a branch, select the main branch and /(root), then Save.
5. Open the Pages URL shown by GitHub after deployment completes.

The supplied HTML is a standalone app. It is not already hosted at a public website URL.
